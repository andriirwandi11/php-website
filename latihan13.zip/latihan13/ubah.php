<?php
require 'function.php';

//ambil data di URL
$id = $_GET["id"];

//query data mhs berdasarkan ID
$mhs = query("SELECT * FROM mahasiswa WHERE id = $id")[0];



//connect to DBMS
$conn = mysqli_connect("localhost", "root", "", "phpdasar");

// buat cek button sudah di tekan/blm
if( isset ($_POST["submit"]) ){

    //cek ubah data berhasil/tidak
    if ( ubah($_POST) > 0 ){
        echo "
            <script>
                alert('Data Berhasil di Ubah!');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
        <script>
            alert('Data Gagal di Ubah!');
            document.location.href = 'index.php';
         </script>
        ";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Mahasiswa</title>
</head>
<body>

    <h1>Update Data Mahasiswa</h1>

    <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $mhs["id"]; ?>">
            <ul>
                <li>
                    <label for="nim">NIM : </label>
                    <input type="text" name="nim" id="nim" require="" value="<?= $mhs["nim"]; ?>">
                </li>
                <li>
                    <label for="nama">Nama : </label>
                    <input type="text" name="nama" id="nama" require="" value="<?= $mhs["nama"]; ?>">
                </li>
                <li>
                    <label for="email">Email : </label>
                    <input type="text" name="email" id="email" require="" value="<?= $mhs["email"]; ?>">
                </li>
                <li>
                    <label for="nim">Jurusan : </label>
                    <input type="text" name="jurusan" id="jurusan" require="" value="<?= $mhs["jurusan"]; ?>">
                </li>
                <li>
                    <label for="gambar">Gambar : </label>
                    <img src="Asset/<?= $mhs['gambar']; ?>">
                    <input type="file" name="gambar" id="gambar">
                </li>
                    <button type="submit" name="submit">UPDATE DATA</button>
            </ul>
    </form>
    
</body>
</html>